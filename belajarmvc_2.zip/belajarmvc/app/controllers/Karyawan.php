<?php

class Karyawan extends Controller {

    // API service 
    public function index($nik = null) {
        if (is_null($nik)) {
            // handle collective request
            switch ($_SERVER['REQUEST_METHOD']) {
                case "GET":
                    // get by name 
                    $name = isset($_GET['nama']) ? $_GET['nama'] : null;
                    if ($name) {
                        echo $this->jsonify(
                            $this->model('Karyawan_model')->getByName($name)
                        );
                        break;
                    }

                    // value foto
                    if (isset($_FILES['foto'])) {
                        $file = $_FILES['foto'];
                        $fileName = $_FILES['foto']['name'];
                        $fileTmpName = $_FILES['foto']['tmp_name'];
                        $fileSize = $_FILES['foto']['size'];
                        $fileError = $_FILES['foto']['error'];

                        // Validasi upload file
                        if ($fileError === 0) {
                            if ($fileSize < 2000000) { // 2MB
                                $uploadDir = 'lc/images/'; // Pastikan folder ini ada
                                $fileDestination = $uploadDir . basename($fileName);
                                
                                // Pindahkan file ke direktori tujuan
                                if (move_uploaded_file($fileTmpName, $fileDestination)) {
                                    // Simpan informasi karyawan ke database, termasuk $fileDestination untuk foto
                                    // Contoh:
                                    $data_in = [
                                        'nama' => $_POST['nama'], // Ambil data lain sesuai kebutuhan
                                        'foto' => $fileDestination,
                                        // Tambahkan field lain sesuai model Anda
                                    ];
                                    echo $this->jsonify(
                                        $this->model('Karyawan_model')->insert($data_in)
                                    );
                                } else {
                                    echo "Gagal mengupload file.";
                                }
                            } else {
                                echo "Ukuran file terlalu besar.";
                            }
                        } else {
                            echo "Ada kesalahan saat mengupload file.";
                        }
                    }

                    //  get All
                    echo $this->jsonify(
                        $this->model('Karyawan_model')->getAll()
                    );
                    break;

                case "POST":
                    // Get data in 
                    $data_in = json_decode(file_get_contents("php://input"), true);
                    echo $this->jsonify(
                        $this->model('Karyawan_model')->insert($data_in)
                    );
                    break;

                default:
                    // Allowed http request methods
                    http_response_code(405);
                    header('Allow: GET, POST');
                    break;
            }
        } else {
            // Handle single request
            switch ($_SERVER['REQUEST_METHOD']) {
                case "GET":
                    echo $this->jsonify(
                        $this->model('Karyawan_model')->getById($nik)
                    );
                    break;

                case 'DELETE':
                    echo $this->jsonify(
                        $this->model('Karyawan_model')->deleteById($nik)
                    );
                    break;

                case "PUT":
                    // retrieve data that comes in the request
                    $new_data = json_decode(file_get_contents("php://input"), true);
                    // Get data current in table karyawan
                    $current = $this->model("Karyawan_model")->getById($nik);
                    $data_karyawan_now = $current['data'];

                    echo $this->jsonify(
                        $this->model("Karyawan_model")->updateData($data_karyawan_now, $new_data)
                    );
                    break;

                default:
                    // Allowed http request method
                    http_response_code(405);
                    header('Allow: GET, PUT, DELETE');
                    break;
            }
        }
    }

    public function table() {
        // page title 
        $data['page-title'] = "Karyawan Data LC"; 

        // load css header 
        $data['css'] = [
            '/css/vendors/jquery.dataTables.min.css',
            '/css/vendors/bootstrap.min.css',
        ];

        // pre-js di header
        $data['pre-js'] = [
            ['type'=> 'text/javascript', 'url'=> '/js/vendors/jquery-3.7.1.min.js'],
            ['type'=> 'text/javascript', 'url'=> '/js/vendors/jquery.dataTables.min.js'],
            ['type'=> 'text/javascript', 'url'=> '/js/vendors/bootstrap.min.js'],
            ['type'=> 'text/javascript', 'url'=> '/js/vendors/bootstrap.bundle.min.js'],
        ];

        $karyawan = $this->model('Karyawan_model')->getAll();
        if ($karyawan['status_code'] == 200) {
            $data['karyawan'] = $karyawan['data'];
        } else {
            $data['karyawan'] = [];
        }

        // load js di body
        $data['js'] = [
            ['type'=> 'text/javascript', 'url'=> '/js/karyawan/table.js'],
            ['type'=> 'text/javascript', 'url'=> '/js/karyawan/script.js'],
        ];

        $this->view("common/header", $data);
        $this->view("karyawan/insert", $data);
        $this->view("common/footer", $data);
    }

    public function detail($nik) {
        // page title
        $data['page-title'] = "Detail Karyawan";

        $karyawan = $this->model('Karyawan_model')->getById($nik);
        $data['karyawan'] = $karyawan['data'];

        $this->view("common/header", $data);
        $this->view("karyawan/detail", $data);
        $this->view("common/footer", $data);
    }

    public function update($nik) {
        $data['page-title'] = 'Halaman Edit';
        
        $karyawan = $this->model('Karyawan_model')->getById($nik);
        $data['karyawan'] = $karyawan['data'];

        $this->view("common/header", $data);
        $this->view("karyawan/edit", $data);
        $this->view("common/footer", $data);
    }
}
