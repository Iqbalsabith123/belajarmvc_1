<?php

// loads env
$dotenv = new DotEnv($_SERVER['DOCUMENT_ROOT'].'/belajarmvc/app/.env');
$dotenv->load();

//jika pakai XAMPP di localhost atau pakai USBWebserver, pakai $_SERVER['HTTP_HOST']
//jika pakai live hosting, pakai $_SERVER['SERVER_ADDR']

if($_ENV['APP_ENV'] == 'dev'){
	define('BASEURL', 'http://'.$_SERVER['HTTP_HOST'].'/belajarmvc/lc');
}elseif($_ENV['APP_ENV'] == 'prod'){
	define('BASEURL','http://'. $_SERVER['SERVER_ADDR'] .'/belajarmvc/lc');
}else throw new Exception("Configuration Error", 1);

//main end point
define('HOMEPAGE', BASEURL.'/home');

//DB
define('DB_HOST', $_ENV['DB_HOST']);
define('DB_USER', $_ENV['DB_USER']);
define('DB_PASS', $_ENV['DB_PASS']);
define('DB_NAME', $_ENV['DB_NAME']);
define('DB_PORT', $_ENV['DB_PORT']);
define('APP_VERSION', $_ENV['APP_VERSION']);