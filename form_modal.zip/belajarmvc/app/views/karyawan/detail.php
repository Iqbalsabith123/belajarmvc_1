<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<div class="container mt-4">
    <div class="card" style="width: 18rem;">
        <img src="<?=$data['karyawan']['foto'];?>" class="card-img-top" alt="Foto Karyawan">
        <div class="card-body">
            <h5 class="card-title"><?=$data['karyawan']['nik'];?></h5>
            <h6 class="card-subtitle mb-2 text-muted"><?=$data['karyawan']['name'];?></h6>
            <p class="card-text"><strong>Section Code:</strong> <?=$data['karyawan']['section_code'];?></p>
            <p class="card-text"><strong>Join Date:</strong> <?=$data['karyawan']['join_date'];?></p>
            <p class="card-text"><strong>Gender:</strong> <?=$data['karyawan']['gender'];?></p>
            <p class="card-text"><strong>Status:</strong> <?=$data['karyawan']['status'];?></p>
            <p class="card-text"><strong>Job Position:</strong> <?=$data['karyawan']['job_position'];?></p>
            <p class="card-text"><strong>Shop ID:</strong> <?=$data['karyawan']['shop_id'];?></p>
            <p class="card-text"><strong>Group:</strong> <?=$data['karyawan']['grup'];?></p>
            <p class="card-text"><strong>Bus Point:</strong> <?=$data['karyawan']['bus_point'];?></p>
            <a href="<?=BASEURL;?>/karyawan/table" class="btn btn-primary">Kembali ke Daftar Karyawan</a>
        </div>
    </div>
</div>


