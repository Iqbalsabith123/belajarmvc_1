<div class="float">
    <h1>Welcome to New Way!</h1>
    <h3>PHPMVC Template</h3>
    <p>For who wants to start own project faster and more scalable.<br/>
    This template is free to use, if you want to thank me then buy me a cup of coffee.</p>
    <a href="<?=BASEURL?>/LICENSE.txt">
        <p class="dark-text" >Copyright &copy; 2023 Galih Sterisma</p>
    </a>
</div>
<div id="particles-js"></div>

<script>
    // how to use particles.js:
    // particlesJS.load('id-of-container-element', 'presets-configs-json', 'optional-callback')
    particlesJS.load('particles-js', './js/home/particles.json');
</script>