
const post = (data)=>{
    return new Promise((resolve, reject)=>{
        const uri = `http://localhost/belajarmvc/lc/karyawan`;
        const xhr = new XMLHttpRequest;

        xhr.open("post", uri, true);
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.responseType = "json";
        xhr.send(JSON.stringify(data));

        xhr.addEventListener("loadend", ()=>{
            if(xhr.status == 201){
                resolve(xhr.response.message);
            }else{
                reject(xhr.response.message);
            }
        })
    })
}

const deleteKaryawan = (id)=>{
        return new Promise((resolve, reject)=>{
            const uri = `http://localhost/belajarmvc/lc/karyawan/${id}`;
            const xhr = new XMLHttpRequest;

            xhr.open("delete", uri, true);
            xhr.responseType = "json";
            xhr.send();

            xhr.addEventListener("loadend", ()=>{
                if(xhr.status == 200){
                    resolve(xhr.response.message);
                }else{
                    reject(xhr.response.message);
                };
        })
    })
}

(document.querySelectorAll('button.btn-delete') || []).forEach((btn)=>{
    btn.addEventListener('click', async function(){
        try {
            let jawab = window.confirm('Anda yakin menghapus data ini?');
            if( jawab){
                res = await deleteKaryawan(this.name)
                alert(res)
                window.location.reload();
            }
        } catch (error) {
            alert(error);
        }
    })
})

document.getElementById('toggle-form').addEventListener('click', function() {
    const form = document.getElementById('employee-form');
    if (form.style.display === 'none') {
        form.style.display = 'block';
        this.textContent = 'Selesai';
    } else {
        form.style.display = 'none';
        this.textContent = 'Tambah Data Karyawan';
    }
});

document.getElementById('btn-submit').addEventListener("click", async ()=>{
    try {
        const data = {
            nik : document.getElementById('nik').value ?? null,
            name : document.getElementById('name').value ?? null,
            section_code : document.getElementById('section_code').value ?? null,
            join_date : document.getElementById('join_date').value ?? null,
            gender : document.getElementById('gender').value ?? null,
            status : document.getElementById('status').value ?? null,
            job_position : document.getElementById('job_position').value ?? null,
            shop_id : document.getElementById('shop_id').value ?? null,
            grup : document.getElementById('grup').value ?? null,
            bus_point : document.getElementById('bus_point').value ?? null,
            foto : document.getElementById('foto').value ?? null
        }
        let res = await post(data);
        console.log(res);
        alert('data berhasil ditambah')
    } catch (error) {
        alert(error);
        console.log('data gagal ditambah')
    }
})


