<?php
	
	/**
	 * this class is built to handle form security againts csrf attacks
	 */

	class CSRF{
		
		/*
		* generates csrf token then asign it to a session
		* params : 
		* output : 
		*/
		public static function generateToken(){

	    	// // use this if using PHP5
	    	// $_SESSION['csrf']['token'] = substr(base_convert(sha1(uniqid(mt_rand())), 16, 36), 0, 32);

	    	// // use this if using PHP7
		    // // $_SESSION['csrf-token'] = bin2hex(random_bytes(32));

		    // // 3 minutes expiration time
		    // $_SESSION['csrf']['expire'] = time() + 180;

		    $_SESSION['csrf'] = [
		    	'token' => substr(base_convert(sha1(uniqid(mt_rand())), 16, 36), 0, 32),
		    	'expire' => time() + 180
		    ];
		}

		/*
		* verify the token that was sent via post method against its session
		* params : $token
		* output : bool
		*/
		public static function verifyToken($token){

			// (1) csrf token is valid
			if($token == $_SESSION['csrf']['token']){
				// (1.a) check token expiration
				if(time() >= $_SESSION['csrf']['expire']){
					return false;
				}else{
					return true;
				}
				// and then unset the sessions
				unset($_SESSION['csrf']);				
			}else{
				// (2) invalid token
				return false;
			}
		}
	}