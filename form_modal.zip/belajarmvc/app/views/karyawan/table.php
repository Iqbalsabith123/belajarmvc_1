<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<div class="container mt-4">
    <h2 class="mb-4">Daftar Karyawan</h2>
    <table class="table table-bordered table-striped">
        <thead class="thead-dark">
            <tr>
                <th>Nik</th>
                <th>Name</th>
                <th>Section Code</th>
                <th>Join Date</th>
                <th>Gender</th>
                <th>Status</th>
                <th>Job Position</th>
                <th>Shop ID</th>
                <th>Group</th>
                <th>Bus Point</th>
                <th>Foto</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($data['karyawan'] as $kryw) : ?>
                <tr>
                    <td><?=$kryw['nik'];?></td>
                    <td><?=$kryw['name'];?></td>
                    <td><?=$kryw['section_code'];?></td>
                    <td><?=$kryw['join_date'];?></td>
                    <td><?=$kryw['gender'];?></td>
                    <td><?=$kryw['status'];?></td>
                    <td><?=$kryw['job_position'];?></td>
                    <td><?=$kryw['shop_id'];?></td>
                    <td><?=$kryw['grup'];?></td>
                    <td><?=$kryw['bus_point'];?></td>
                    <td><img src="<?=$kryw['foto'];?>" alt="Foto" style="width: 50px; height: 50px;" class="img-thumbnail"></td>
                    <td>
                        <div class="d-flex">
                            <button class="btn btn-warning mr-2 btn-edit" data-nik="<?=$kryw['nik']; ?>">Edit</button>
                            <button class="btn btn-danger btn-del" data-nik="<?=$kryw['nik']; ?>">Delete!</button>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

