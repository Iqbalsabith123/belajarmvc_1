<?php

if(!session_id()) session_start();

require_once '../app/init.php';

set_error_handler("ErrorHandler::handleError");
set_exception_handler("ErrorHandler::handleException");

$app = new App;