<?php

class Karyawan extends Controller {

    // API service 
    public function index($nik=null){
        if(is_null($nik)){
            // handle colective request
            switch($_SERVER['REQUEST_METHOD']) {
                case "GET" :
                    // get by name 
                    $name = isset($_GET['nama'])? $_GET['nama'] : null;
                    if($name){
                        echo $this->jsonify(
                            $this->model('Karyawan_model')->getByName($name)
                        );
                        break;
                    }

                    //  get All
                    echo $this->jsonify(
                        $this->model('Karyawan_model')->getAll()
                    );
                    break;

                case "POST" : 
                    // Get data in 
                    $data_in = json_decode(file_get_contents("php://input"), true);

                    // Now $data_in -> array assoc
                    echo $this->jsonify(
                        $this->model('Karyawan_model')->insert($data_in)
                    );
                    break;

                default:
                    // Allowed http request methods
                    http_response_code(405);
                    header('Allow: GET, POST');
                    break;
            }
        }else{
            // Handle single request
            switch ($_SERVER['REQUEST_METHOD']) {
                case "GET" :
                    echo $this->jsonify(
                        $this->model('Karyawan_model')->getById($nik)
                    );
                    break;

                case 'DELETE' :
                    echo $this->jsonify(
                    $this->model('Karyawan_model')->deleteById($nik)
                    );
                    break;
                    
                
                case "PUT" :
                    // retrieve data that comes in the request
                    $new_data = json_decode(file_get_contents("php://input"), true);

                    // Get data current in table karyawan
                    $current = $this->model("Karyawan_model")->getById($nik);
                    $data_karyawan_now = $current['data'];

                    echo $this->jsonify(
                        $this->model("Karyawan_model")->updateData($data_karyawan_now, $new_data)
                    );
                    break;

                default:
                    // Allowed http request method
                    http_response_code(405);
                    header('Allow: GET, PUT, DELETE');
                    break;
                    
            }
        }
    }

    public function table(){
        // page title 
        $data['page-title'] = "Karyawan Data LC"; 

        // load css header 
        $data['css'] = [
            '/css/vendors/jquery.dataTables.min.css',
            '/css/vendors/bootstrap.min.css',
        ];

        // pre-js di header
        $data['pre-js'] = [
            ['type'=> 'text/javascript', 'url'=> '/js/vendors/jquery-3.7.1.min.js'],
            ['type'=> 'text/javascript', 'url'=> '/js/vendors/jquery.dataTables.min.js'],
            ['type'=> 'text/javascript', 'url'=> '/js/vendors/bootstrap.min.js'],
            ['type'=> 'text/javascript', 'url'=> '/js/vendors/bootstrap.bundle.min.js'],
        ];


        $karyawan = $this->model('Karyawan_model')->getAll();
        if( $karyawan['status_code']==200){
            $data['karyawan'] = $karyawan['data'];
        }else{
            $data['karyawan']=[];
        }

        // load js di body
        $data['js'] = [
            ['type'=> 'text/javascript', 'url'=> '/js/karyawan/table.js'],
            ['type'=> 'text/javascript', 'url'=> '/js/karyawan/script.js'],
        ];
        

        $this->view("common/header", $data);
        $this->view("karyawan/insert", $data);
        $this->view("common/footer", $data);
    }

    // public function table(){
    //     // page title
    //     $data["page-title"] = "Table Karyawan";
    //     $karyawan = $this->model('Karyawan_model')->getAll();
    //     $data['karyawan'] = $karyawan['data'];

    //     $this->view("common/header", $data);
    //     $this->view("karyawan/table", $data);
    //     $this->view("common/footer", $data);
    // }

    public function detail($nik){
        //page title
        $data['page-title'] = "detail Karyawan";

        $karyawan = $this->model('Karyawan_model')->getById($nik);
        $data['karyawan'] = $karyawan['data'];

        $this->view("common/header", $data);
        $this->view("karyawan/detail", $data);
        $this->view("common/footer", $data);
    }

    public function update($nik){
        $data['page-title'] = 'Halaman Edit';
        
        $karyawan = $this->model('Karyawan_model')->getById($nik);
        $data['karyawan'] = $karyawan['data'];

        $this->view("common/header", $data);
        $this->view("karyawan/edit", $data);
        $this->view("common/footer", $data);

    }
}
