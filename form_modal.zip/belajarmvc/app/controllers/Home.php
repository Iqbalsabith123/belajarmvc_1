<?php

class Home extends Controller{

	public function index(){
		// page title
		$data['page-title'] = "Welcome";

		// css
		$data['css'] = [
			'/css/home/welcome.css'
		];

		// preload images
		$data['preload'] = [];

		// compose pre-js
		$data['pre-js'] = [
			[
				'type' =>'text/javascript',
				'url'  =>'/js/vendors/particles.min.js'
			],
		];

		// compose js:
		$data['js'] = [];

		$this->view("common/header", $data);
		$this->view("home/welcome", $data);
		$this->view("common/footer", $data);
	}
}