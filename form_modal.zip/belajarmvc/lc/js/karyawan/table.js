// halaman table
$(document).ready(function() {
    $('#employee-table').DataTable();
});