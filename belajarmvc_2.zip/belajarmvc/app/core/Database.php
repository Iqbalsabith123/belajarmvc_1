<?php

class Database {
    private $host = DB_HOST;
    private $user = DB_USER;
    private $pass = DB_PASS;
    private $dbname = DB_NAME;
    private $port = DB_PORT;

    private $dbh;
    private $stmt;


    // init the class
    public function __construct($db_name=null){
        //note penting: port diisi dengan port mysql sesuai setingan defaultnya
        //$dsn = 'mysql:host=' . $this->host . ';dbname=' . $this->dbname . ';port=3306';

        // if db_name is provided, set db name as appropriate one
        if(!is_null($db_name)){
            $this->dbname = $db_name;
        }
        
        $dsn = 'pgsql:host='.$this->host.';dbname='.$this->dbname.';port='.$this->port;

        $option = [
            PDO::ATTR_PERSISTENT => TRUE,
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ];

        try{
            $this->dbh = new PDO($dsn, $this->user, $this->pass, $option);
            //echo "Database connected!";
        }catch(PDOException $e){
            echo "Database tidak berhasil connect";
        }
    }


    // prepare the query
    public function query($query){
        $this->stmt = $this->dbh->prepare($query);
    }


    // bind value(s) to the prepared query
    public function bind($param, $value, $type = null){
        if(is_null($type)){
            switch(true){
                case is_int($value):
                    $type = PDO::PARAM_INT;
                break;
                case is_bool($value):
                    $type = PDO::PARAM_BOOL;
                break;
                case is_null($value):
                    $type = PDO::PARAM_NULL;
                break;
                default:
                    $type = PDO::PARAM_STR;
            }
        }

        $this->stmt->bindValue($param, $value, $type);
    }


    // execute prepared query
    public function execute(){
        $this->stmt->execute();
    }


    // return fetch all
    // ouput type is array associative
    public function resultSet(){
        $this->execute();
        return $this->stmt->fetchAll(PDO::FETCH_ASSOC);
    }


    // return fetch one
    // output type is single array associative
    public function single(){
        $this->execute();
        return $this->stmt->fetch(PDO::FETCH_ASSOC);
    }


    // return affected row(s) by the query
    public function rowCount(){
        return $this->stmt->rowCount();
    }


    // begin the transaction
    public function beginTransaction(){
        $this->dbh->beginTransaction();
    }


    // commit prepared transaction
    public function commit(){
        $this->dbh->commit();
    }


    // cancel prepared transaction
    public function rollback(){
        $this->dbh->rollback();
    }


    // checks if a transaction is currently active within the driver.
    // this method only works for database drivers that support transaction.
    // return bool
    public function inTransaction(){
        $this->dbh->inTransaction();
    }


    // frees up the connection to server so that other query may be issued
    public function closeCursor(){
        $this->stmt->closeCursor();
    }


    // return the ID of the last inserted row, or last value
    public function lastInsertId(){
        $this->dbh->lastInsertId();
    }

}