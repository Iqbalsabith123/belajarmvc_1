
const post = (data)=>{
    return new Promise((resolve, reject)=>{
        const uri = `http://localhost/belajarmvc/lc/karyawan`;
        const xhr = new XMLHttpRequest;

        xhr.open("post", uri, true);
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.responseType = "json";
        xhr.send(JSON.stringify(data));

        xhr.addEventListener("loadend", ()=>{
            if(xhr.status == 201){
                resolve(xhr.response.message);
            }else{
                reject(xhr.response.message);
            }
        })
    })
}

const deleteKaryawan = (id)=>{
        return new Promise((resolve, reject)=>{
            const uri = `http://localhost/belajarmvc/lc/karyawan/${id}`;
            const xhr = new XMLHttpRequest;

            xhr.open("delete", uri, true);
            xhr.responseType = "json";
            xhr.send();

            xhr.addEventListener("loadend", ()=>{
                if(xhr.status == 200){
                    resolve(xhr.response.message);
                }else{
                    reject(xhr.response.message);
                };
        })
    })
}

(document.querySelectorAll('button.btn-delete') || []).forEach((btn)=>{
    btn.addEventListener('click', async function(){
        try {
            let jawab = window.confirm('Anda yakin menghapus data ini?');
            if( jawab){
                res = await deleteKaryawan(this.name)
                alert(res)
                window.location.reload();
            }
        } catch (error) {
            alert(error);
        }
    })
})


document.getElementById('btn-submit').addEventListener("click", async ()=>{
    try {
        const data = {
            nik : document.getElementById('nik').value ?? null,
            name : document.getElementById('name').value ?? null,
            section_code : document.getElementById('section_code').value ?? null,
            join_date : document.getElementById('join_date').value ?? null,
            gender : document.getElementById('gender').value ?? null,
            status : document.getElementById('status').value ?? null,
            job_position : document.getElementById('job_position').value ?? null,
            shop_id : document.getElementById('shop_id').value ?? null,
            grup : document.getElementById('grup').value ?? null,
            bus_point : document.getElementById('bus_point').value ?? null,
            foto : document.getElementById('foto').value ?? null
        }
        let res = await post(data);
        console.log(res);
        alert('data berhasil ditambah')
    } catch (error) {
        alert(error);
        console.log('data gagal ditambah')
    }
})

// ini buat modal di dalam insert detail
$(document).ready(function() {
    $('.btn-view').click(function(e) {
        e.preventDefault(); // Mencegah redirect

        // Ambil data dari atribut
        $('#modal-nik').text($(this).data('nik'));
        $('#modal-name').text($(this).data('name'));
        $('#modal-section-code').text($(this).data('section_code'));
        $('#modal-join-date').text($(this).data('join_date'));
        $('#modal-gender').text($(this).data('gender'));
        $('#modal-status').text($(this).data('status'));
        $('#modal-job-position').text($(this).data('job_position'));
        $('#modal-shop-id').text($(this).data('shop_id'));
        $('#modal-grup').text($(this).data('grup'));
        $('#modal-bus-point').text($(this).data('bus_point'));

    })
})


// Update data karyawan yang di insert

const put = (data)=>{
    return new Promise((resolve, reject)=>{
        const uri = `http://localhost/belajarmvc/lc/karyawan/${data.nik}`;
        const xhr = new XMLHttpRequest();

        xhr.open("put", uri, true);
        xhr.setRequestHeader("Content-type", "application/json");
        xhr.responseType = "json";
        xhr.send(JSON.stringify(data));

        xhr.addEventListener("loadend", ()=>{
            if(xhr.status == 200){
                resolve(xhr.response.message);
                alert('data berhasil di Edit!');
            }else{
                reject(xhr.response.message);
                alert('data gagal di Edit!');

            }
        })
    })
}


// document.getElementById('btn-edit').addEventListener('click', async ()=>{
//     try {
//         const data = {
//             nik: document.getElementById('nik').value,
//             name: document.getElementById('name').value,
//             section_code: document.getElementById('section_code').value,
//             join_date: document.getElementById('join_date').value,
//             gender: document.getElementById('gender').value,
//             status: document.getElementById('status').value,
//             job_position: document.getElementById('job_position').value,
//             shop_id: document.getElementById('shop_id').value,
//             grup: document.getElementById('grup').value,
//             bus_point: document.getElementById('bus_point').value,
//             foto: document.getElementById('foto').value,
//         };


//         let res = await put(data);
//         alert(res);
//         console.log('oke');
//     } catch (error) {
//         alert(error)
//         console.log('error');
        
//     }
// })


$(document).ready(function() {
    // edit tombol di click
    $('.btn-edit').click(function() {
        // Get data attributes from the clicked button
        const nik = $(this).data('nik');
        const name = $(this).data('name');
        const section_code = $(this).data('section_code');
        const join_date = $(this).data('join_date');
        const gender = $(this).data('gender');
        const status = $(this).data('status');
        const job_position = $(this).data('job_position');
        const shop_id = $(this).data('shop_id');
        const grup = $(this).data('grup');
        const bus_point = $(this).data('bus_point');

        // form edit datanya 
        $('#edit-nik').val(nik);
        $('#edit-name').val(name);
        $('#edit-section_code').val(section_code);
        $('#edit-join_date').val(join_date);
        $('#edit-gender').val(gender);
        $('#edit-status').val(status);
        $('#edit-job_position').val(job_position);
        $('#edit-shop_id').val(shop_id);
        $('#edit-grup').val(grup);
        $('#edit-bus_point').val(bus_point);
    });

    // Update data xhr nya
    const put = (data) => {
        return new Promise((resolve, reject) => {
            const uri = `http://localhost/belajarmvc/lc/karyawan/${data.nik}`;
            const xhr = new XMLHttpRequest();

            xhr.open("PUT", uri, true);
            xhr.setRequestHeader("Content-type", "application/json");
            xhr.responseType = "json";
            xhr.send(JSON.stringify(data));

            xhr.addEventListener("loadend", () => {
                if (xhr.status === 200) {
                    resolve(xhr.response.message);
                    alert('Data berhasil di Edit!');
                } else {
                    reject(xhr.response.message);
                    alert('Data gagal di Edit!');
                }
            });
        });
    };

    document.getElementById('btn-edit').addEventListener('click', async () => {

        const data = {
            nik: document.getElementById('edit-nik').value,
            name: document.getElementById('edit-name').value,
            section_code: document.getElementById('edit-section_code').value,
            join_date: document.getElementById('edit-join_date').value,
            gender: document.getElementById('edit-gender').value,
            status: document.getElementById('edit-status').value,
            job_position: document.getElementById('edit-job_position').value,
            shop_id: document.getElementById('edit-shop_id').value,
            grup: document.getElementById('edit-grup').value,
            bus_point: document.getElementById('edit-bus_point').value,
        };

        try {
            let res = await put(data);
            alert(res);
            console.log('Data updated successfully');
        } catch (error) {
            alert(error);
            console.log('Error updating data');
        }
    });
});