<!DOCTYPE html>
<html lang="en">

<head>
	<!-- meta tags -->
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- page title -->
	<title><?= $data['page-title']; ?></title>

	<!-- load css -->
	<?php 
		if(isset($data['css'])){
			foreach($data['css'] as $css){ 
	?>
		<link rel="stylesheet" type="text/css" href="<?= BASEURL.$css; ?>">
	<?php 
			}; //<-- close foreach
		}; //<-- close if isset
	?>


	<!-- load pre-js -->
	<?php
		if(isset($data['pre-js'])){
			foreach($data['pre-js'] as $key => $js){
	?>
		<script type="<?=$js['type'];?>" src="<?=BASEURL.$js['url'];?>"></script>
	<?php
			};
		};
	?>	


	<!-- preloads -->
	<?php 
		if(isset($data['preload'])){
			foreach($data['preload'] as $preload){ 
	?>
		<link rel="preload" as="image" href="<?= BASEURL.$preload; ?>">
	<?php 
			}; //<-- close foreach
		}; //<-- close if isset
	?>

	<!-- load icon -->
	<link rel="icon" type="favicon" href="<?= BASEURL; ?>/images/favicon-32x32.png">
	
</head>

<body>