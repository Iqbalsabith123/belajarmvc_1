<?php

class Controller {

    public function view($view, $data = []){
        require_once '../app/views/' . $view . '.php';
    }

    public function model($model, $dbname=null){
        require_once '../app/models/' . $model . '.php';
		if(!is_null($dbname)){
			return new $model($dbname);
		}
        return new $model;
    }

    public function send_as_json($response_code, $message, $data=null, $method='GET'){
    	//set response header as json type
    	header('Access-Control-Allow-Origin: *');
		header("Content-Type: application/json");

		if($response_code == 200 && (is_null($data) or empty($data) or $data==false)){
			if($method == 'GET'){
				http_response_code(404);
				return json_encode(['message' => 'data not found', 'data' => null], JSON_PRETTY_PRINT);
			}
		}

		$response = [
			'message' => $message,
			'data' => $data
		];

		http_response_code($response_code);
		return json_encode($response, JSON_PRETTY_PRINT);
    }


	public function send_as_json_with_safe_null($response_code, $message, $data=null, $method='GET'){
		//set response header as json type
    	header('Access-Control-Allow-Origin: *');
		header("Content-Type: application/json");

		if($response_code == 200 && (is_null($data) or empty($data) or $data==false)){
			if($method == 'GET'){
				http_response_code(200);
				return json_encode(['message' => 'data not found', 'data' => []], JSON_PRETTY_PRINT);
			}
		}

		$response = [
			'message' => $message,
			'data' => $data
		];

		http_response_code($response_code);
		return json_encode($response, JSON_PRETTY_PRINT);
	}

	public function jsonify($response){
		// set response header as json type
		header('Acces-Control-Allow-Origin: *');
		header('Content-Type: application/json');
		http_response_code($response['status_code']);
		return json_encode($response, JSON_PRETTY_PRINT);
	}

	
    
}