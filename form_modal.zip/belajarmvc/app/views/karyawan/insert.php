
<!-- Buat modal toogel -->
<div class="container mt-5">
    <button id="toggle-form" class="btn btn-secondary mb-3" data-toggle="modal" data-target="#employeeModal">Tambah Data Karyawan</button>

    <!-- ini inputan form di dalam modal -->
    <div class="modal fade" id="employeeModal" tabindex="-1" aria-labelledby="employeeModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="employeeModalLabel">Tambah Data Karyawan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    </button>
                </div>
                <div class="modal-body">
                    <form id="employee-form" action="" method="post" class="bg-light p-4 rounded">
                        <div class="form-group">
                            <label for="nik">Masukan Nik :</label>
                            <input type="text" name="nik" id="nik" class="form-control" placeholder="Masukan Nik anda">
                        </div>

                        <div class="form-group">
                            <label for="name">Masukan Nama :</label>
                            <input type="text" name="name" id="name" class="form-control" placeholder="Masukan nama anda">
                        </div>

                        <div class="form-group">
                            <label for="section_code">Masukan Section Code :</label>
                            <input type="text" name="section_code" id="section_code" class="form-control" placeholder="Masukan section code anda">
                        </div>

                        <div class="form-group">
                            <label for="join_date">Masukan Join Date :</label>
                            <input type="date" name="join_date" id="join_date" class="form-control" placeholder="Masukan join date anda">
                        </div>

                        <div class="form-group">
                            <label for="gender">Masukan Gender :</label>
                            <input type="text" name="gender" id="gender" class="form-control" placeholder="Masukan gender anda">
                        </div>

                        <div class="form-group">
                            <label for="status">Masukan Status :</label>
                            <input type="text" name="status" id="status" class="form-control" placeholder="Masukan status anda">
                        </div>

                        <div class="form-group">
                            <label for="job_position">Masukan Job Position :</label>
                            <input type="text" name="job_position" id="job_position" class="form-control" placeholder="Masukan job position anda">
                        </div>

                        <div class="form-group">
                            <label for="shop_id">Masukan Shop :</label>
                            <input type="text" name="shop_id" id="shop_id" class="form-control" placeholder="Masukan shop anda">
                        </div>

                        <div class="form-group">
                            <label for="grup">Masukan Grup :</label>
                            <input type="text" name="grup" id="grup" class="form-control" placeholder="Masukan grup anda">
                        </div>

                        <div class="form-group">
                            <label for="bus_point">Masukan Bus Point :</label>
                            <input type="text" name="bus_point" id="bus_point" class="form-control" placeholder="Masukan bus point anda">
                        </div>

                        <div class="form-group">
                            <label for="foto">Masukan Foto :</label>
                            <input type="text" name="foto" id="foto" class="form-control" placeholder="Masukan foto anda">
                        </div>

                        <button type="submit" id="btn-submit" class="btn btn-primary">Kirim!</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mt-5">
    <h2 class="mb-4">Daftar Karyawan</h2>
    <table id="employee-table" class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>NIK</th>
                <th>Nama</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($data['karyawan'] as $kryw) : ?>
            <tr>
                <td><?=$kryw['nik']?></td>
                <td><?=$kryw['name']?></td>
                <td>
                    <a href="<?=BASEURL;?>/karyawan/detail/<?=$kryw['nik']?>" class="btn btn-info btn-sm">Lihat</a>
                    <a href="<?=BASEURL;?>/karyawan/update/<?=$kryw['nik'];?>" class="btn btn-primary btn-sm">Edit</a>
                    <button name="<?=$kryw['nik']?>" class="btn btn-danger btn-sm btn-delete">Delete</button>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
