<?php

class Flasher {
    
    public static function setFlash($subj, $msg, $act, $type){
        $_SESSION['flash'] = [
            'subjek' => $subj,
            'pesan' => $msg,
            'aksi' => $act,
            'tipe' => $type
        ];

    }

// uncomment below if you use bootstrap
    // public static function flash(){
    //     if ( isset($_SESSION['flash']) ){
    //         echo '<div class="alert alert-' . $_SESSION['flash']['tipe'] . ' alert-dismissible fade show" role="alert">'
    //                 . $_SESSION['flash']['subjek'] . '<strong>' . $_SESSION['flash']['pesan'] . '</strong> ' . $_SESSION['flash']['aksi'] . '
    //                 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    //                 <span aria-hidden="true">&times;</span>
    //                 </button>
    //             </div>';
    //         unset($_SESSION['flash']);
    //     }
    // }

//uncomment below if you use bulma
    public static function flash(){
        if(isset($_SESSION['flash'])){
            echo '<div class="notification is-' .$_SESSION['flash']['tipe'] . ' is-light"><button class="delete" aria-label="close"></button>'
                 . $_SESSION['flash']['subjek'] . '<strong>' . $_SESSION['flash']['pesan'] . '</strong>' . $_SESSION['flash']['aksi'] .
                 '</div>';

            unset($_SESSION['flash']);
        }
    }
}