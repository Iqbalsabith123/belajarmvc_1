<?php
class Karyawan_model{
    // properti 
    private $table = 'karyawan';
    private $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    public function getAll(){
        try {
            $stmt = "SELECT * FROM ". $this->table;

            $this->db->query($stmt); // prepare query statement
            $res = $this->db->resultSet(); // Data berupa array assoc
            if($res) return ["status_code" => 200, "message"=> "success", "num_row"=> count($res), "data" => $res];
        } catch (\Throwable $th) {
            //throw
            return ["status_code"=> 500, "message"=> $th->getMessage()];
        }
    }

    public function getById($nik){
        try {
            $sql = "SELECT * FROM ". $this->table ." WHERE nik = :nik";

            $this->db->query($sql);
            $this->db->bind(':nik', $nik );
            $res = $this->db->single();
            if($res) return ["status_code"=> 200, "message"=> "success", "data"=> $res];
            return["status_code"=> 404, "message"=>"Data Not Found!"];
        } catch (\Throwable $th) {
            return["status_code"=> 500, "message"=> $th->getMessage()];
        }
    }

    /***
     *  get elemen by name in database include single data 
    ***/
    public function getByName($name){
        try {
            $sql = "SELECT * FROM ". $this->table. " WHERE name LIKE :name";

            $this->db->query($sql);
            $this->db->bind(':name', $name);
            $res = $this->db->single();
            if($res) return["status_code"=> 200, "message"=> "success", "data"=> $res ];
            return["status_code"=> 404, "message"=> "Data Not Found!"];
        } catch (\Throwable $th) {
            return["status_code"=> 500, "message"=> $th->getMessage()];
        }
    }

    // $data --> array assoc
    // $data['nik];
    // $data['name];
    // $data['gender];
    // $data['status];
    // $data['shop];
    public function insert($data){
        try {
            $stmt = "INSERT INTO ".$this->table ."(nik, name, section_code, join_date, gender, status, job_position, shop_id, grup, bus_point, foto) VALUES (:nik, :name, :section_code, :join_date, :gender, :status, :job_position, :shop_id, :grup, :bus_point, :foto)";
            $this->db->query($stmt);
            $this->db->bind(":nik", $data['nik']);
            $this->db->bind(":name", $data['name']);
            $this->db->bind(":section_code", $data['section_code']);
            $this->db->bind(":join_date", $data['join_date']);
            $this->db->bind(":gender", $data['gender']);
            $this->db->bind(":status", $data['status']);
            $this->db->bind(":job_position", $data['job_position']);
            $this->db->bind(":shop_id", $data['shop_id']);
            $this->db->bind(":grup", $data['grup']);
            $this->db->bind(":bus_point", $data['bus_point']);
            $this->db->bind(":foto", $data['foto']);

            $this->db->execute();

            $rows = $this->db->rowCount(); // get jumlah baris yang bertambah
            if($rows>0) return["status_code"=> 201, "message"=>"Data berhasil di tambah"];
            return ["status_code"=> 400, "message"=> "Data gagal ditambahkan"];

        } catch (\Throwable $th) {
            return["status_code"=> 500, "message"=> $th->getMessage()];
        }
    }

    /***
    * Delete data get by id 
    ***/

    public function deleteById($nik){
        try {
            $this->db->beginTransaction();

            $sql = "DELETE FROM ".$this->table ." WHERE nik = :nik";
            $this->db->query($sql);
            $this->db->bind(':nik', $nik);
            $this->db->execute();
            $rows = $this->db->rowCount();
            if($rows>0) {
                $this->db->commit();
                return["status_code"=>200, "message"=> "data has been successful deleted!"];
            }
            // rollback
            $this->db->rollback();
            return["status_code"=> 400, "message"=> "data failed deleted!"];

        } catch (\Throwable $th) {
            $this->db->rollback();
            return["status_code" => 500, $th->getMessage()];
        }
    }

    public function updateData($current, $new) {
        try {
            // Mulai transaksi
            $this->db->beginTransaction();
    
            // Membangun query SQL
            $sql = "UPDATE " . $this->table . " SET 
                name = :name,
                section_code = :section_code,
                gender = :gender,
                status = :status,
                job_position = :job_position,
                shop_id = :shop_id,
                grup = :grup,
                bus_point = :bus_point,
                foto = :foto
                WHERE nik = :nik";
    
            // Menyiapkan query
            $this->db->query($sql);
    
            // Mengikat parameter
            $this->db->bind(":name", (isset($new['name'])) ? $new['name'] : $current['name']);
            $this->db->bind(":section_code", (isset($new['section_code'])) ? $new['section_code'] : $current['section_code']);
            $this->db->bind(":gender", (isset($new['gender'])) ? $new['gender'] : $current['gender']);
            $this->db->bind(":status", (isset($new['status'])) ? $new['status'] : $current['status']);
            $this->db->bind(":job_position", (isset($new['job_position'])) ? $new['job_position'] : $current['job_position']);
            $this->db->bind(":shop_id", (isset($new['shop_id'])) ? $new['shop_id'] : $current['shop_id']);
            $this->db->bind(":grup", (isset($new['grup'])) ? $new['grup'] : $current['grup']);
            $this->db->bind(":bus_point", (isset($new['bus_point'])) ? $new['bus_point'] : $current['bus_point']);
            $this->db->bind(":foto", (isset($new['foto'])) ? $new['foto'] : $current['foto']);
            $this->db->bind(":nik", $current['nik']); // NIK seharusnya selalu dari current
    
            // Menjalankan query
            $this->db->execute();
    
            // Mengambil jumlah baris yang terpengaruh
            $rows = $this->db->rowCount();
            if ($rows > 0) {
                $this->db->commit(); // Komit transaksi jika ada baris yang terpengaruh
                return ["status_code" => 200, "message" => "Data berhasil diperbarui"];
            } else {
                $this->db->rollBack(); // Rollback jika tidak ada baris yang terpengaruh
                return ["status_code" => 404, "message" => "Tidak ada perubahan yang dilakukan"];
            }
        } catch (\Throwable $th) {
            $this->db->rollBack(); // Rollback jika terjadi kesalahan
            return ["status_code" => 500, "message" => $th->getMessage()];
        }
    }  
};