<?php

class Cache{
	protected $cachefile;

	public function __construct($cachefile){
		$this->cachefile = $cachefile;
	}

	public function save($sourcedata){
		// simpan data sumber menjadi cache file
		$json = json_encode($sourcedata);
		$foh = fopen($this->cachefile, "w+");

		// terapkan metode locking pada saat menulis ke file
		// locking yang digunakan adalah:
		// LOCK_EX --> Exclusive Locking, biasanya digunakan saat operasi write
		// LOCK_NB --> Non-Blocked Locking, ini akan membuat proses locking tidak bisa diblock
		// LOCK_UN --> Un-Locked, untuk membuka Locking

		if(ENABLE_LOCK_NB){
			if( flock($foh, LOCK_EX | LOCK_NB) ){
				fwrite($foh, $json);
				fflush($foh);
				flock($foh, LOCK_UN);
			}
		}else{
			if( flock($foh, LOCK_EX) ){
				fwrite($foh, $json);
				fflush($foh);
				flock($foh, LOCK_UN);
			}
		}

		// close the file
		fclose($foh);
	}


	public function get(){
		if( file_exists($this->cachefile) ){
			$cache_data = file_get_contents($this->cachefile);
			$data = json_decode($cache_data, true);
			return $data;
		}else{
			return null;
		}
	}
}