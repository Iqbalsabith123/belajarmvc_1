<!-- Include Bootstrap CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<div class="container mt-5">
    <h2 class="mb-4">Edit Data Karyawan</h2>
    <form id="employee-edit-form" action="" method="post" class="bg-light p-4 rounded">
        
        <div class="form-group">
            <label for="nik">Masukan Nik :</label>
            <input type="text" name="nik" id="nik" class="form-control" value="<?=$data['karyawan']['nik'];?>" readonly>
        </div>

        <div class="form-group">
            <label for="name">Masukan Nama :</label>
            <input type="text" name="name" id="name" class="form-control" value="<?=$data['karyawan']['name'];?>">
        </div>

        <div class="form-group">
            <label for="section_code">Masukan Section Code :</label>
            <input type="text" name="section_code" id="section_code" class="form-control" value="<?=$data['karyawan']['section_code'];?>">
        </div>

        <div class="form-group">
            <label for="join_date">Masukan Join Date :</label>
            <input type="date" name="join_date" id="join_date" class="form-control" value="<?=$data['karyawan']['join_date'];?>">
        </div>

        <div class="form-group">
            <label for="gender">Masukan Gender :</label>
            <select name="gender" id="gender" class="form-control">
                <option value="M" <?= $data['karyawan']['gender'] == 'M' ? 'selected' : '' ;?>>M</option>
                <option value="F" <?= $data['karyawan']['gender'] == 'Fe' ? 'selected' : '' ;?>>F</option>
            </select>
        </div>

        <div class="form-group">
            <label for="status">Masukan Status :</label>
            <input type="text" name="status" id="status" class="form-control" value="<?=$data['karyawan']['status'];?>">
        </div>

        <div class="form-group">
            <label for="job_position">Masukan Job Position :</label>
            <input type="text" name="job_position" id="job_position" class="form-control" value="<?=$data['karyawan']['job_position'];?>">
        </div>

        <div class="form-group">
            <label for="shop_id">Masukan Shop :</label>
            <input type="text" name="shop_id" id="shop_id" class="form-control" value="<?=$data['karyawan']['shop_id'];?>">
        </div>

        <div class="form-group">
            <label for="grup">Masukan Grup :</label>
            <input type="text" name="grup" id="grup" class="form-control" value="<?=$data['karyawan']['grup'];?>">
        </div>

        <div class="form-group">
            <label for="bus_point">Masukan Bus Point :</label>
            <input type="text" name="bus_point" id="bus_point" class="form-control" value="<?=$data['karyawan']['bus_point'];?>">
        </div>

        <div class="form-group">
            <label for="foto">Masukan Foto :</label>
            <input type="text" name="foto" id="foto" class="form-control" value="<?=$data['karyawan']['foto'];?>">
        </div>

        <button type="submit" id="btn-submit" class="btn btn-success">Update!</button>
        <a href="<?=BASEURL;?>/karyawan/table" class="btn btn-primary">Kembali ke Daftar Karyawan</a>
    </form>
</div>

<script>
    const put = (data)=>{
        return new Promise((resolve, reject)=>{
            const uri = `http://localhost/belajarmvc/lc/karyawan/${data.nik}`;
            const xhr = new XMLHttpRequest();

            xhr.open("put", uri, true);
            xhr.setRequestHeader("Content-type", "application/json");
            xhr.responseType = "json";
            xhr.send(JSON.stringify(data));

            xhr.addEventListener("loadend", ()=>{
                if(xhr.status == 200){
                    resolve(xhr.response.message);
                    alert('data berhasil di Edit!');
                }else{
                    reject(xhr.response.message);
                    alert('data gagal di Edit!');

                }
            })
        })
    }


    document.getElementById('btn-submit').addEventListener('click', async ()=>{
        try {
            const data = {
                nik: document.getElementById('nik').value,
                name: document.getElementById('name').value,
                section_code: document.getElementById('section_code').value,
                join_date: document.getElementById('join_date').value,
                gender: document.getElementById('gender').value,
                status: document.getElementById('status').value,
                job_position: document.getElementById('job_position').value,
                shop_id: document.getElementById('shop_id').value,
                grup: document.getElementById('grup').value,
                bus_point: document.getElementById('bus_point').value,
                foto: document.getElementById('foto').value,
            };


            let res = await put(data);
            alert(res);
            console.log('oke');
        } catch (error) {
            alert(error)
            console.log('error');
            
        }
    })
</script>
