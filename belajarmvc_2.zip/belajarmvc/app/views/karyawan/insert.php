<div class="container mt-5">
    <button id="toggle-form" class="btn btn-secondary mb-3" data-toggle="modal" data-target="#addEmployeeModal">Tambah Data
        Karyawan</button>

    <!-- Modal untuk Tambah Data Karyawan -->
    <div class="modal fade" id="addEmployeeModal" tabindex="-1" aria-labelledby="addEmployeeModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addEmployeeModalLabel">Tambah Data Karyawan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="employee-form" action="" method="post" class="bg-light p-4 rounded"
                        enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="nik">Masukan Nik :</label>
                            <input type="text" name="nik" id="nik" class="form-control"
                                placeholder="Masukan Nik anda">
                        </div>
                        <div class="form-group">
                            <label for="name">Masukan Nama :</label>
                            <input type="text" name="name" id="name" class="form-control"
                                placeholder="Masukan nama anda">
                        </div>
                        <div class="form-group">
                            <label for="section_code">Masukan Section Code :</label>
                            <input type="text" name="section_code" id="section_code" class="form-control"
                                placeholder="Masukan section code anda">
                        </div>
                        <div class="form-group">
                            <label for="join_date">Masukan Join Date :</label>
                            <input type="date" name="join_date" id="join_date" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="gender">Masukan Gender :</label>
                            <input type="text" name="gender" id="gender" class="form-control"
                                placeholder="Masukan gender anda">
                        </div>
                        <div class="form-group">
                            <label for="status">Masukan Status :</label>
                            <input type="text" name="status" id="status" class="form-control"
                                placeholder="Masukan status anda">
                        </div>
                        <div class="form-group">
                            <label for="job_position">Masukan Job Position :</label>
                            <input type="text" name="job_position" id="job_position" class="form-control"
                                placeholder="Masukan job position anda">
                        </div>
                        <div class="form-group">
                            <label for="shop_id">Masukan Shop :</label>
                            <input type="text" name="shop_id" id="shop_id" class="form-control"
                                placeholder="Masukan shop anda">
                        </div>
                        <div class="form-group">
                            <label for="grup">Masukan Grup :</label>
                            <input type="text" name="grup" id="grup" class="form-control"
                                placeholder="Masukan grup anda">
                        </div>
                        <div class="form-group">
                            <label for="bus_point">Masukan Bus Point :</label>
                            <input type="text" name="bus_point" id="bus_point" class="form-control"
                                placeholder="Masukan bus point anda">
                        </div>
                        <div class="form-group">
                            <label for="foto">Masukan Foto :</label>
                            <input type="file" name="foto" id="foto" class="form-control">
                        </div>
                        <button type="submit" id="btn-submit" class="btn btn-primary">Kirim!</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal untuk Edit Data Karyawan -->
    <div class="modal fade" id="editEmployeeModal" tabindex="-1" aria-labelledby="editEmployeeModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editEmployeeModalLabel">Edit Data Karyawan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="edit-employee-form" action="" method="post" class="bg-light p-4 rounded">
                        <div class="form-group">
                            <label for="edit-nik">NIK :</label>
                            <input type="text" name="nik" id="edit-nik" class="form-control" readonly>
                        </div>
                        <div class="form-group">
                            <label for="edit-name">Nama :</label>
                            <input type="text" name="name" id="edit-name" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="edit-section_code">Section Code :</label>
                            <input type="text" name="section_code" id="edit-section_code" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="edit-join_date">Join Date :</label>
                            <input type="date" name="join_date" id="edit-join_date" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="edit-gender">Gender :</label>
                            <input type="text" name="gender" id="edit-gender" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="edit-status">Status :</label>
                            <input type="text" name="status" id="edit-status" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="edit-job_position">Job Position :</label>
                            <input type="text" name="job_position" id="edit-job_position" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="edit-shop_id">Shop ID :</label>
                            <input type="text" name="shop_id" id="edit-shop_id" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="edit-grup">Group :</label>
                            <input type="text" name="grup" id="edit-grup" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="edit-bus_point">Bus Point :</label>
                            <input type="text" name="bus_point" id="edit-bus_point" class="form-control">
                        </div>
                        <button type="submit" id="btn-edit" class="btn btn-primary">Update!</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <h2 class="mb-4">Daftar Karyawan</h2>
    <table id="employee-table" class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>NIK</th>
                <th>Nama</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($data['karyawan'] as $kryw) : ?>
            <tr>
                <td><?= $kryw['nik'] ?></td>
                <td><?= $kryw['name'] ?></td>
                <td>
                    <button href="" data-nik="<?= $kryw['nik'] ?>" data-name="<?= $kryw['name'] ?>"
                        data-section_code="<?= $kryw['section_code'] ?>" data-join_date="<?= $kryw['join_date'] ?>"
                        data-gender="<?= $kryw['gender'] ?>" data-status="<?= $kryw['status'] ?>"
                        data-job_position="<?= $kryw['job_position'] ?>" data-shop_id="<?= $kryw['shop_id'] ?>"
                        data-grup="<?= $kryw['grup'] ?>" data-bus_point="<?= $kryw['bus_point'] ?>"
                        data-foto="<?= BASEURL . '/path/to/images/' . $kryw['foto'] ?>"
                        class="btn btn-info btn-sm btn-view" data-toggle="modal" data-target="#detailModal">Lihat</button>

                    <button class="btn btn-primary btn-sm btn-edit" data-nik="<?= $kryw['nik'] ?>"
                        data-name="<?= $kryw['name'] ?>" data-section_code="<?= $kryw['section_code'] ?>"
                        data-join_date="<?= $kryw['join_date'] ?>" data-gender="<?= $kryw['gender'] ?>"
                        data-status="<?= $kryw['status'] ?>" data-job_position="<?= $kryw['job_position'] ?>"
                        data-shop_id="<?= $kryw['shop_id'] ?>" data-grup="<?= $kryw['grup'] ?>"
                        data-bus_point="<?= $kryw['bus_point'] ?>" data-foto="<?= $kryw['foto'] ?>"
                        data-toggle="modal" data-target="#editEmployeeModal">Edit</button>

                    <button name="<?= $kryw['nik'] ?>" class="btn btn-danger btn-sm btn-delete">Delete</button>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Modal untuk Detail Karyawan -->
<div class="modal fade" id="detailModal" tabindex="-1" aria-labelledby="detailModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="detailModalLabel">Detail Karyawan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p><strong>NIK:</strong> <span id="modal-nik"></span></p>
                <p><strong>Nama:</strong> <span id="modal-name"></span></p>
                <p><strong>Section Code:</strong> <span id="modal-section-code"></span></p>
                <p><strong>Join Date:</strong> <span id="modal-join-date"></span></p>
                <p><strong>Gender:</strong> <span id="modal-gender"></span></p>
                <p><strong>Status:</strong> <span id="modal-status"></span></p>
                <p><strong>Job Position:</strong> <span id="modal-job-position"></span></p>
                <p><strong>Shop ID:</strong> <span id="modal-shop-id"></span></p>
                <p><strong>Group:</strong> <span id="modal-grup"></span></p>
                <p><strong>Bus Point:</strong> <span id="modal-bus-point"></span></p>
                <p><strong>Foto:</strong></p>
                <img id="modal-foto" src="" alt="Foto Karyawan" class="img-fluid">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>

  


