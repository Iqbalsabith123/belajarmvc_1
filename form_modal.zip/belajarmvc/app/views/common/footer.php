<!-- load js -->
<?php 
	if(isset($data['js'])){
		foreach($data['js'] as $key => $js){
?>
	<script type="<?= $js['type']; ?>" src="<?= BASEURL.$js['url']; ?>"></script>
<?php 
		}; //<-- close foreach
	}; //<-- close isset
?>

</body>
</html>