<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Upload</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">

</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 upload-form">
                <h2 class="text-center">Upload Gambar</h2>
                <form action="" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="fileInput">Ambil gambar:</label>
                        <input type="file" name="namafile" class="form-control-file" id="fileInput" required />
                    </div>
                    <button type="submit" name="upload" class="btn btn-primary btn-block">Simpan</button>
                </form>
            </div>
        </div>
    </div>

    <?php

    
            // $host = 'localhost'; 
            // $user = 'postgres'; 
            // $pass = ''; 
            // $dbname = 'jajal'; 

            // $conn = new mysqli($host, $user, $pass, $dbname);


            // if ($conn->connect_error) {
            //     die("Connection failed: " . $conn->connect_error);
            // }


        // spesifikasi file std rumahafif
        $ukuranfile = 3 * 1024 * 1024; 
        $allowed = ['image/jpeg', 'image/png', 'image/gif'];

        if ($_FILES) {
            $namaberkas = $_FILES['namafile']['name'];
            $fileberkas = $_FILES['namafile']['tmp_name'];
            $fileSize = $_FILES['namafile']['size'];
            $fileType = $_FILES['namafile']['type'];

            $upload_file = 'C:/laragon/www/uploadnative/images/';

            if ($fileSize > $ukuranfile) {
                echo '<script>showAlert("File terlalu besar. Maksimum ukuran file adalah 3MB.");</script>';
            } elseif (!in_array($fileType, $allowed)) {
                echo '<script>showAlert("Tipe file tidak diizinkan. Hanya JPG, PNG, dan GIF yang diperbolehkan.");</script>';
            } else {
                // untuk fungsi upload
                if (move_uploaded_file($fileberkas, $upload_file . $namaberkas)) {
                    echo '<script>showAlert("File ' . htmlspecialchars($namaberkas) . ' berhasil diupload.");</script>';
                } else {
                    echo '<script>showAlert("Gagal memindahkan file ke direktori tujuan.");</script>';
                }
            }
        }
    ?>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="script.js"></script>
</body>
</html>
