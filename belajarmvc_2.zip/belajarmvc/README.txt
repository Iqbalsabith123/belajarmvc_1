/*-----------------------------------------------------------------------------------------
PHPMVC Template
Created by Galih Sterisma
License of this template and all of the files within this template are follow MIT License.
If you want to thank me then buy me a cup of coffee.
------------------------------------------------------------------------------------------*/

This README file covers how to use this template properly,
so you can use it by yourself.

<[1]>. Folder structure
	in the beginning, this template has folder structure as below:
		phpmvc
		|
		+--- app
		|
		+--- public
		|
		+--- .htaccess
		|
		+--- README.txt
		|
		+--- version.txt
	phpmvc folder is designed as your domain name.

	(1-1). app folder
		this folder is private and do not expose what inside it to anyone!
		so it has .htaccess on its own to prevent direct access.
		
	(1-2). public folder
		everyone can see this folder. this folder is designed as your mainroute.

	(1-3). .htaccess
		first entry point. this file has ht rule to make this template works properly.

	(1-4). README.txt
		the file you reading now.

	(1-5). version.txt
		this file stores and indicates your application version.


<[2]>. Public folder
	Public folder is typically your mainroute. this folder can be accessed by everyone.
	so this folder is suitable for keeping your assets such as images, css, js, License or changelogs.
	this folder has structure as below:
		public
			|
			+--- css				: folder to store all css files you need
			|
			+--- fonts				: folder to store all fonts you need
			|
			+--- images				: folder to store all images
			|
			+--- js					: folder to store all js files you need
			|
			+--- sounds				: folder to store all sound or audio files
			|
			+--- .htaccess			: entry point to route to index.php
			|
			+--- changelogs.txt		: keeps track your changes
			|
			+--- LICENSE.txt		: license of this file follows MIT License
			|
			+--- index.php			: index file. this is main file


<[3]>. App folder
	App folder is a private folder. it's secured by .htaccess file that has rule to prevent direct access from outside application.
	this folder must not to be renamed, otherwise you know what you're doing.
	this folder contains class and utility functions that features this app so well.
	this folder has structure as below:
		app
			|
			+--- config				: contains config.php that stores configuration for this app to run properly
			|
			+--- controllers		: folder to store all controllers you need. controller is class to route a page.
			|
			+--- core				: contains classes as well as engine for this app
			|
			+--- models				: folder to store all models you need. model is class to interact with database
			|
			+--- vendors			: folder to store all third parties classes.
			|
			+--- views				: folder to store all view file. view is what user see in the browser
			|
			+--- .env				: env file that stores super secret informations. you dont share this file to anyone
			|
			+--- .htaccess			: ht rule to prevent direct access
			|
			+--- init.php			: calling all the required class to load.


<[4]>. How to create project using this template**
	this template is designed as 'domain/mainroute' whereas phpmvc as a domain, and public as a mainroute.
	**in this section i will make an example what if i create a new project called 'epicking/lc',
	as your image, see below comparation between original and example.
		purpose:  domain   /  mainroute
		original: phpmvc   /  public
					||        	||
					\/        	\/
		example: epicking  /    lc

		(4-1). you may rename this 'phpmvc' folder to be your application or domain name.
				example: you rename 'phpmvc' to 'epicking'

		(4-2). you may rename the 'public' folder to be your mainroute.
				example: you rename 'public' to 'lc'
				so now the path of this template should be as 'epicking/lc'

		if you do one of the two above or all of them then you must modify the following files:
			1. .htaccess inside the phpmvc (now is epicking) folder
				update the RewriteRule ^$ it has to be mainroute/home [L]
				so now according to this example is should be as RewriteRule ^$ lc/home [L]

			2. .htaccess inside the public (now is lc) folder
				update the RewriteRule (.*) it has to be mainroute/$1 [L]
				so now according to this example is should be as RewriteRule (.*) lc/$1 [L]

			3. Config.php file inside the app/config folder
				--- update the path to env file at the $dotenv declaration
					so now according to this example is should be $dotenv = new DotEnv($_SERVER['DOCUMENT_ROOT'].'/epicking/app/.env')

				--- update the path to main route at the BASEURL declaration for both app environment (dev and prod)
					so now according to this example is should be define('BASEURL', 'http://'.$_SERVER['HTTP_HOST'].'/epicking/lc')

		(4-3). you may modify .env file as you need
				you can change the database name, host, port, password, etc.
				all secret informations can be saved here.


That's all from me.
Happy coding with this template.